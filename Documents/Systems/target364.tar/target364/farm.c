/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_123(unsigned x)
{
    return x + 3284633928U;
}

void setval_419(unsigned *p)
{
    *p = 952340568U;
}

unsigned getval_165()
{
    return 2425374885U;
}

void setval_172(unsigned *p)
{
    *p = 2428963144U;
}

unsigned addval_358(unsigned x)
{
    return x + 3281031256U;
}

unsigned getval_414()
{
    return 1016054360U;
}

unsigned addval_382(unsigned x)
{
    return x + 3347662855U;
}

void setval_445(unsigned *p)
{
    *p = 3284633672U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_138(unsigned *p)
{
    *p = 3465107102U;
}

void setval_363(unsigned *p)
{
    *p = 3682910873U;
}

unsigned getval_409()
{
    return 3677934025U;
}

void setval_102(unsigned *p)
{
    *p = 3767093481U;
}

unsigned addval_292(unsigned x)
{
    return x + 3375419017U;
}

void setval_294(unsigned *p)
{
    *p = 3281047945U;
}

void setval_384(unsigned *p)
{
    *p = 3769190578U;
}

unsigned getval_407()
{
    return 3373843081U;
}

void setval_320(unsigned *p)
{
    *p = 3221275273U;
}

unsigned addval_487(unsigned x)
{
    return x + 3221799563U;
}

void setval_477(unsigned *p)
{
    *p = 3680555401U;
}

unsigned getval_495()
{
    return 3224945289U;
}

unsigned addval_489(unsigned x)
{
    return x + 3222851209U;
}

void setval_404(unsigned *p)
{
    *p = 3252717896U;
}

unsigned getval_335()
{
    return 197378697U;
}

unsigned getval_304()
{
    return 3674787469U;
}

unsigned getval_339()
{
    return 2425406105U;
}

void setval_446(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_197()
{
    return 2425409161U;
}

unsigned addval_277(unsigned x)
{
    return x + 3523268233U;
}

void setval_145(unsigned *p)
{
    *p = 3286239560U;
}

void setval_273(unsigned *p)
{
    *p = 3526939016U;
}

void setval_187(unsigned *p)
{
    *p = 3222851209U;
}

void setval_432(unsigned *p)
{
    *p = 3767093410U;
}

void setval_263(unsigned *p)
{
    *p = 3675836809U;
}

unsigned getval_248()
{
    return 3525890441U;
}

unsigned addval_367(unsigned x)
{
    return x + 2425409929U;
}

unsigned addval_178(unsigned x)
{
    return x + 3682914761U;
}

unsigned getval_476()
{
    return 3771287593U;
}

unsigned getval_369()
{
    return 3682127497U;
}

void setval_173(unsigned *p)
{
    *p = 2495777052U;
}

unsigned getval_284()
{
    return 2430634314U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
